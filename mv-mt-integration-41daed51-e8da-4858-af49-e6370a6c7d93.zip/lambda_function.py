"""Set the Environment Information Needed to Access Your Lab!

The provided sample code in this repository will reference this file to get the
information needed to connect to your lab backend.  You provide this info here
once and the scripts in this repository will access it as needed by the lab.


Copyright (c) 2018 Cisco and/or its affiliates.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED 'AS IS', WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""

# Libraries
import sys, os, getopt, json
import base64
import adaptive_cards
import requests
import time
import datetime
import boto3
import botocore
from dateutil import tz

# Read environment variables
region_name = os.environ.get('REGION_NAME')
base_url = os.environ.get('MERAKI_BASEURL')
wt_room_name = os.environ.get('WT_ROOM_NAME')
msteamsurl = os.environ.get('MS_TEAMS_URL')
dynamodb_table = os.environ.get('DYNAMODB_TABLE')

print('Region name ',region_name)
print('Base url ',base_url)
print('Webex room ID ',wt_room_name)
print('MS teams url ',msteamsurl)
print('DynamoDB table ', dynamodb_table)

# Obtain secrets from Secrets Manager
secrets_mgr = boto3.client('secretsmanager', region_name=region_name)
try:
    webex_token = json.loads(secrets_mgr.get_secret_value(SecretId='Webex-Access-Token')['SecretString'])['Webex-Access-Token']
except botocore.exceptions.ClientError as e:
    print(e)
    webex_flag = False
    print(webex_flag)
else:
    webex_flag = True
    print(webex_flag)
api_key = json.loads(secrets_mgr.get_secret_value(SecretId='X-Cisco-Meraki-API-Key')['SecretString'])['X-Cisco-Meraki-API-Key']

# Instantiate DynamoDB client
dynamodb = boto3.client('dynamodb', region_name=region_name)

if msteamsurl != '':
    msteams_flag = True
else:
    msteams_flag = False

# Webhook Receiver Code - Accepts JSON POST from Meraki and
# Posts to WebEx Teams
def lambda_handler(event, context):
    # Webhook Receiver
    print(event)
    # Gather Alert Data
    alert_type = event['alertType']
    alert_id = event['alertId']
    organization_name = event['organizationName']
    network_name = event['networkName']
    network_id = event['networkId']
    device_model = event['deviceModel']
    device_name = event['deviceName']
    device_url = event['deviceUrl']
    
    # Ensure this alert has not been seen before
    # If new, take not of the alert_id and add it to your dynamodb database
    # If duplicate, stop all processing
    try:
        response = dynamodb.get_item(TableName=dynamodb_table,Key={'alertId': {'S': alert_id}})['Item']
        print(response)
    except KeyError as e:
        print('New alert.')
        response = dynamodb.put_item(
                        TableName=dynamodb_table,
                        Item={
                            'alertId': {'S': alert_id}
                        }
                    )
        new_alert = True
    else:
        print('Duplicate alert.')
        new_alert = False
    
    # Get timezone info from Meraki Dashboard to properly display timestamps in
    # Notifications
    if new_alert==True:
        time_zone = get_timezone(network_id)
        print(f'Timezone is {time_zone}')
        if time_zone != None:
            tz_dt = tz.gettz(time_zone)
            print(f'Timezone is {tz_dt}')
        else:
            tz_dt = None
            print(f'Timezone is {tz_dt}')
    
            
        #Workflow for Sensors
        if alert_type == 'Sensor change detected':
            #Obtain basic alert data
            print('Sensor change detected')
            sensor_value = event['alertData']['triggerData'][0]['trigger']['sensorValue']
            alert_ts = event['alertData']['triggerData'][0]['trigger']['ts']
    
            #Workflow for door sensor with Snapshot API
            print(device_model)
            print(sensor_value)
            
            # If receiving a door open event, continue here
            if device_model == 'MT20' and sensor_value == 1.0:
                print('Open Door alert!')
                # Snapshot timestamp must be in ISO format
                
                # Check camera that maps to this sensor based on mv-SERIAL tag in the sensor
                # Check if this camera requires a delay in seconds to capture the appropriate
                # image of the person from the delay-SECONDS tag in the sensor
                for sensor_tag in event['deviceTags']:
                    if 'mv-Q' in sensor_tag:
                        cam_serial = sensor_tag.lstrip('mv-')
                    
                    if 'delay-' in sensor_tag:
                        delay = sensor_tag.lstrip('delay-')
                        cam_alert_ts = int(delay) + alert_ts
                # Snapshots referenced with timestamps may take a minute to be available
                # During which fetching will likely fail
                # This loops 10 times (150 seconds) or exits
                iso_ts = datetime.datetime.utcfromtimestamp(alert_ts).isoformat() + 'Z'
                print('Requesting video link...')
                vid = video(camera=cam_serial, iso_ts=iso_ts, 
                        network_name=network_name, alert_ts=alert_ts)
                print('Requesting camera snapshot...')
                
                # Handle delay requirement for tagged cameras
                # If cam_iso_ts does not exist, just use regular iso_ts
                try:
                    if cam_alert_ts:
                        cam_iso_ts = datetime.datetime.utcfromtimestamp(cam_alert_ts).isoformat() + 'Z'
                        snap = snapshot(camera=cam_serial, iso_ts=cam_iso_ts, 
                            network_name=network_name, alert_ts=cam_alert_ts)
                except:
                    snap = snapshot(camera=cam_serial, iso_ts=iso_ts, 
                        network_name=network_name, alert_ts=alert_ts)
                print('Creating adaptive card')
                open_door(
                    network_name=network_name,
                    sensor_name=device_name,
                    model_name=device_model,
                    sensor_link=device_url,
                    snapshot_link=snap.json()['url'],
                    video_link=vid.json()['url'],
                    alert_ts=alert_ts,
                    tz_dt=tz_dt
                )
                
                # After successfully sending the adaptive card, update the dynamodb record
                # with metadata from the event for future revision
                response = dynamodb.put_item(
                    TableName=dynamodb_table,
                    Item={'alertId': {'S': alert_id},
                        'alertType': {'S': alert_type},
                        'networkName': {'S': network_name},
                        'sensorName': {'S': device_name},
                        'sensorLink': {'S': device_url},
                        'snapshotLink': {'S': snap.json()['url']},
                        'videoLink': {'S': vid.json()['url']},
                        'isoTs': {'S': str(iso_ts)}
                    })
        
        # If receiving a motion alert, go here                        
        if alert_type == 'Motion detected':
            print('Motion alert!')
            image_url = event['alertData']['imageUrl']
            alert_ts = event['alertData']['timestamp']
            for cam_tag in event['deviceTags']:
                if 'mt-Q' in cam_tag:
                    sensor_serial = cam_tag.lstrip('mt-')
                    iso_ts = datetime.datetime.utcfromtimestamp(alert_ts).isoformat() + 'Z'
                    print('Requesting video link...')
                    vid = video(camera=event['deviceSerial'], iso_ts=iso_ts, 
                            network_name=network_name, alert_ts=alert_ts)
                    motion_recap(
                        network_id=network_id,
                        sensor=sensor_serial,
                        video = vid,
                        event= event,
                        alert_ts=alert_ts,
                        image_url=image_url,
                        tz_dt=tz_dt
                    )
                    # After successfully sending the adaptive card, update the dynamodb record
                    # with metadata from the event for future revision
                    response = dynamodb.put_item(
                        TableName=dynamodb_table,
                        Item={'alertId': {'S': alert_id},
                            'alertType': {'S': alert_type},
                            'networkName': {'S': network_name},
                            'cameraName': {'S': device_name},
                            'cameraLink': {'S': device_url},
                            'snapshotLink': {'S': image_url},
                            'videoLink': {'S': vid.json()['url']},
                            'isoTs': {'S': str(iso_ts)}
                        })

# Function for door open alerts from open door events
def open_door(network_name, sensor_name, model_name, sensor_link, alert_ts, snapshot_link, video_link, tz_dt):
    iso_ts = datetime.datetime.fromtimestamp(alert_ts, tz=tz_dt).isoformat() + 'Z'
    card = adaptive_cards.open_door_card(
        network_name=network_name,
        sensor_name=sensor_name,
        model_name=model_name,
        sensor_link=sensor_link,
        snapshot_link=snapshot_link,
        video_link=video_link,
        timestamp=iso_ts
        )
    # Send Adaptive Card to Webex Teams
    if webex_flag == True:
        send_webex_card(card)
            
    # Send Adaptive Card to MS Teams
    if msteams_flag == True:
        send_msteams_card(card=card, url= msteamsurl)

def video(camera, iso_ts, network_name, alert_ts):
    i = 0
    # Try to obtain video link, if not available retry 9 times every 15 seconds
    while i < 10:
        try:
            url = base_url + f'/devices/{camera}/camera/videoLink?timestamp={iso_ts}'
            payload = None

            headers = {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "X-Cisco-Meraki-API-Key": f"{api_key}"
            }
            
            print('Fetching camera video link...')
            video = requests.request('GET', url, headers=headers, data = payload)
            print(f"Video Link status code is {video.status_code}")

            return video
        except:
            time.sleep(15)
            i = i + 1
            if i == 10:
                print('Failed to fetch camera video link.')
            continue
        break
    
def snapshot(camera, iso_ts, network_name, alert_ts):
    i = 0
    # Try to obtain camera snapshot, if not available retry 9 times every 15 seconds
    while i < 10:
        try:
            print('Fetching camera snapshot...')
            url = base_url + f"/devices/{camera}/camera/generateSnapshot"

            payload = {
                "timestamp": f"{iso_ts}"
            }
            headers = {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "X-Cisco-Meraki-API-Key": f"{api_key}"
            }
            
            snap = requests.request('POST', url, headers=headers, data = json.dumps(payload))
            print(f"Snapshot status code is {snap.status_code}")
            if snap.status_code!=202:
                raise Exception("Snapshot not found")
            return snap
        except Exception as e:
            print(e)
            time.sleep(15)
            i = i + 1
            if i == 10:
                print('Failed to fetch camera snapshot.')
            continue
        break

def get_sensor_state(network_id, sensor):
    i=0
    # Try to obtain sensor state, if failed retry 3 times every 2 seconds
    while i < 4:
        try:
            endpoint = f'/networks/{network_id}/sensors/stats/latestBySensor'
            params=f'?metric=door&serials[]={sensor}'
            url = base_url + endpoint + params
            payload = None
            headers = {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "X-Cisco-Meraki-API-Key": f'{api_key}'
            }
        
            sensor_state = requests.request('GET', url, headers=headers, data = payload)
            print(f"Sensor state status code is {sensor_state.status_code}")
            if sensor_state.status_code != 200:
                raise Exception('Unable to obtain sensor state... Retrying...')
            return sensor_state
        except Exception as e:
            print(e)
            time.sleep(2)
            i = i + 1
            if i == 4:
                print('Failed to fetch sensor state.')
            continue
        break

def get_sensor_data(sensor):
    i = 0
    # Try to obtain data of door sensor, if unavailable retry 3 times every 2 seconds
    while i < 4:
        try:
            url = base_url+f"/devices/{sensor}"
            
            payload = None
            
            headers = {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "X-Cisco-Meraki-API-Key": f"{api_key}"
            }
            
            sensor_data = requests.request('GET', url, headers=headers, data = payload)
            print(f"Sensor data status code is {sensor_data.status_code}")
            return(sensor_data)
        except Exception as e:
            print(e)
            time.sleep(2)
            i = i + 1
            if i == 4:
                print('Failed to fetch sensor data.')
            continue
        break

def motion_recap(network_id, sensor, video, event, alert_ts, image_url, tz_dt):
    # Try to obtain sensor state, if failed retry 3 times every 2 seconds
    sensor_state = get_sensor_state(network_id, sensor)

    # If door sensor is open, go here
    if json.loads(sensor_state.text)[0]['value']==1.0:
        i = 0
        # Try to obtain data of door sensor, if unavailable retry 3 times every 2 seconds
        sensor_data = get_sensor_data(sensor)
        
        iso_ts = datetime.datetime.fromtimestamp(alert_ts, tz=tz_dt).isoformat() + 'Z'
        print(sensor_data.json())
        card = adaptive_cards.combo_card(
            network_name=event['networkName'],
            model_name=event['deviceModel'],
            camera_name=event['deviceName'],
            sensor_name=sensor_data.json()['name'],
            timestamp=iso_ts,
            camera_link=video.json()['url'],
            sensor_link=sensor_data.json()['url'],
            snapshot_link=image_url
        )
        if webex_flag == True:
            send_webex_card(card)
        
        if msteams_flag == True:
            send_msteams_card(card=card, url= msteamsurl)

def get_timezone(networkId):
    i = 0
    while i < 4:
        try:
            url = base_url + f'/networks/{networkId}'
            payload = None
            headers = {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "X-Cisco-Meraki-API-Key": f"{api_key}"
            }
            print('Fetching timezone info...')
            network = requests.request('GET', url, headers=headers, data = payload)
            if network.status_code != 200:
                raise Exception('Unable to get timezone info... Retrying...')
                print(network.status_code)
            time_zone = network.json()['timeZone']
            return time_zone
        except Exception as e:
            print(e)
            time.sleep(2)
            i = i + 1
            if i == 4:
                print('Failed to get timezone info.')
                time_zone = None
                return time_zone
            continue
        break

def send_webex_card(card):
    # Obtain Webex Room ID with chatbot
    payload = ''
    
    url = 'https://webexapis.com/v1/rooms'

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {webex_token}"
    }
    
    response = requests.request('GET', url, headers=headers, data = payload)
    rooms = json.loads(response.text)
    for room in rooms['items']:
        if room['title']==wt_room_name:
            wt_room_id = room['id']
    
    # Send Message to previous room
    
    url = 'https://webexapis.com/v1/messages'

    headers =  {'Authorization': f'Bearer {webex_token}',
            'Content-Type': 'application/json'}
    body = {
        "roomId":wt_room_id,
        "text":"fallback",
        "attachments":[card]
    }
    msg = requests.post(url=url, headers=headers, data=json.dumps(body))

def send_msteams_card(card,url):
    card_msteams = {
        "type":"message",
        "attachments":[card]
    }
    msteams_payload = json.dumps(card_msteams)
    msteams_headers = {
        "Content-Type": "application/json"
    }
    requests.request('POST', msteamsurl, headers=msteams_headers, data=msteams_payload)